let dataProducts = `[
    {
    "img": "./Rectangle1.jpg",
    "title": "MANGO PEOPLE T-SHIRT",
    "price": "$300",
    "color": "Red",
    "size": "XL",
    "quantity": "2"
    },
        {
    "img": "./Rectangle2.jpg",
    "title": "ELLERY XMO CAPSULE",
    "price": "52",
    "color": "Black",
    "size": "XL",
    "quantity": "1"
    }
    ]`

